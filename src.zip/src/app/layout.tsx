"use client";

import "./globals.css";
import Navbar from "./components/navbar";
import Footer from "./components/footer";
import { createContext, useState, useEffect, ReactNode } from "react";
import { User, onAuthStateChanged, setPersistence, browserLocalPersistence} from "firebase/auth";
import Loading from "./components/loading";
import { auth } from "@/firebase/firebaseConfig";

type AuthContextType = {
  user: User | null;
  loading: boolean;
};

export const AuthContext = createContext<AuthContextType>({
  user: null,
  loading: true,
});

export default function RootLayout({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Make Firebase persist login across reloads
    setPersistence(auth, browserLocalPersistence)
      .then(() => {
        const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
          setUser(firebaseUser);
          setLoading(false);
        });
        return () => unsubscribe();
      })
      .catch(console.error);
  }, []);

  return (
    <AuthContext.Provider value={{ user, loading }}>
      <html lang="en">
        <body>
          <header><Navbar /></header>
          <main className="min-h-[calc(100vh-9rem)] bg-gray-100 flex flex-col relative items-center justify-center overflow-auto">
            {loading ? <Loading /> : children}
          </main>
          <footer><Footer /></footer>
        </body>
      </html>
    </AuthContext.Provider>
  );
}