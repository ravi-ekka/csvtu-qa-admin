'use client';
import { EditorContent, Extension, useEditor } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import MenuBar from "./MenuBar";
import { useEffect, useState } from "react";

import Heading from '@tiptap/extension-heading'
import { ListItem, OrderedList } from '@tiptap/extension-list'
import Paragraph from '@tiptap/extension-paragraph'
import Text from '@tiptap/extension-text'
import Document from '@tiptap/extension-document'
import TextAlign from '@tiptap/extension-text-align'
import { TextStyle } from '@tiptap/extension-text-style'
import Image from "@tiptap/extension-image";
import FontFamily from "@tiptap/extension-font-family";


export default function Editor({ id, content, type, height, hide, onChange }: any) {


    const FontSize = Extension.create({
        name: 'fontSize',

        addGlobalAttributes() {
            return [
                {
                    types: ['textStyle'],
                    attributes: {
                        fontSize: {
                            default: null,
                            parseHTML: element => element.style.fontSize?.replace(/['"]+/g, ''),
                            renderHTML: attributes => {
                                if (!attributes.fontSize) return {}
                                return { style: `font-size: ${attributes.fontSize}` }
                            },
                        },
                    },
                },
            ]
        },
    })



    const editor = useEditor({
        extensions: [
            StarterKit,
            Document,
            Paragraph,
            Text,
            OrderedList,
            ListItem,
            TextAlign,
            TextStyle,      // ✅ first
            FontSize,
            FontFamily.configure({ types: ['textStyle'] }), // ✅ after TextStyle
            Image,
            Heading.configure({ levels: [1, 2, 3] }),
            TextAlign.configure({ types: ['heading', 'paragraph'] })
        ],

        content: content,
        immediatelyRender: false,
        editable: !hide,
        editorProps: {
            attributes: {
                class:
                    `w-full border border-gray-300 p-2 overflow-y-auto rounded-md focus:outline-none`,
                style: `${height || ""}`
            }
        },
        onUpdate: ({ editor }) => {
            if (editor.getHTML() !== content)
                onChange(id, editor.getHTML(), type);
        }
    });





    useEffect(() => {
        if (editor) {
            editor.setEditable(!hide);
        }
    }, [hide]);
    return (
        <div>
            {
                !hide && <MenuBar editor={editor} />
            }
            <EditorContent editor={editor} />
        </div>

    );
}
