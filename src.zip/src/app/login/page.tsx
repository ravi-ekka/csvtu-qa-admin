"use client";
import { useState } from "react";
import { signInWithEmailAndPassword} from "firebase/auth";
import { auth } from "@/firebase/firebaseConfig";
import { useRouter} from "next/navigation";


export default function Login() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  async function handleLogin() {
    try {
      await signInWithEmailAndPassword(auth, email, password);
      router.refresh()
    } catch (err) {
      console.error(err);
    }
  }

  return (
    <div className="flex items-center justify-center bg-gray-100 min-h-screen">
      <div className="card w-full max-w-md shadow-xl bg-white rounded-xl p-8">
        <h1 className="text-3xl font-bold text-center mb-6 text-gray-800">
          Admin Login
        </h1>
        <input
          type="email"
          placeholder="Email"
          className="input input-bordered w-full mb-4"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="password"
          placeholder="Password"
          className="input input-bordered w-full mb-6"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button onClick={handleLogin} className="btn btn-primary w-full">
          Login
        </button>
      </div>
    </div>
  );
}