'use client';

interface Paper {
  course: string;
  semester: string;
  branch: string;
  subject: string;
  subCode?: string;
  season: string;
  year: number;
}

interface PaperInfoProps {
  data: Paper;
}

export default function PaperInfo({ data }: PaperInfoProps) {
  // prepare label → key pairs for consistent naming
  const fields: { label: string; value: string | number }[] = [
    { label: "Course", value: data?.course ?? "-" },
    { label: "Semester", value: data?.semester ?? "-" },
    { label: "Branch", value: data?.branch ?? "-" },
    { label: "Subject", value: `${data?.subject ?? "-"} (${data?.subCode ?? "-"})` },
    { label: "Season", value: data?.season ?? "-" },
    { label: "Year", value: data?.year ?? "-" },
  ];

  return (
    <section
      className="card w-full max-w-4xl mx-auto"
      aria-labelledby="paperinfo-heading"
    >
      {/* <header className="flex items-center justify-between">
        <h2
          id="paperinfo-heading"
          className="text-sm font-semibold p-0"
        >
          Paper Info
        </h2>
      </header> */}

      <div className="grid grid-cols-3 sm:grid-cols-3 lg:grid-cols-3 p-3 gap-4 place-items-center text-center">
        {fields.map((field, i) => (
          <div key={i} className="flex flex-col">
            <span className="text-xs uppercase tracking-wide text-base-content/60">
              {field.label}
            </span>
            <span className="font-medium text-sm sm:text-base">
              {field.value}
            </span>
          </div>
        ))}
      </div>

    </section>
  );
}
