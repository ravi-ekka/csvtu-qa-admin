'use client';

import { useEffect, useState } from "react";
import Editor from "./Editor";
import { addDoc, collection, doc, getDoc, getDocs, query, setDoc, where } from "firebase/firestore";
import { db } from "@/firebase/firebaseConfig";
import { useSearchParams } from "next/navigation";
import PaperInfo from "./paperInfo";

export default function managePaper() {
    const [data, setData] = useState<any>(null);
    const pid = useSearchParams().get("id");
    const [activeTab, setActiveTab] = useState("paperTab");
    const [qusa, setQusa] = useState<{ id: any; ques: string; ans: string; hide: boolean; isSaved: boolean; isSaving: boolean }[]>([]);
    useEffect(() => {
        if (!pid) return;

        async function paperInfo() {
            try {
                const snap = await getDoc(doc(db, "papers", pid!));
                if (snap.exists()) {
                    setData(snap.data());
                } else {
                    console.log("No such paper!");
                    setData(null);
                }
            } catch (error) {
                console.error("Error fetching paper:", error);
            }
        }

        paperInfo();
    }, [pid]);

    useEffect(() => {
        if (!pid) return;
        async function getQAS() {
            try {
                const qry = query(collection(db, "que-Ans"), where("paperId", "==", pid));
                const snapshot = await getDocs(qry);
                const rusult = snapshot.docs.map((doc) => {
                    const data = doc.data();
                    return {
                        id: doc.id,
                        ques: data.question,
                        ans: data.answare,
                        hide: false,
                        isSaved: true,   // better: mark as saved since it came from Firestore
                        isSaving: false,
                    };
                });         
                setQusa(rusult);
            } catch (error) {
                console.error("Error fetching qa:", error);
            }
        }
        getQAS();
    }, []);
    console.log(qusa);
    function add() {
        const newQa =
        {
            id: crypto.randomUUID(),
            ques: "",
            ans: "",
            hide: false,
            isSaved: false,
            isSaving: false
        };
        setQusa([...qusa, newQa]);
    }
    function toggleHide(id: string) {
        setQusa((prev) =>
            prev.map((qa) =>
                qa.id === id ? { ...qa, hide: !qa.hide } : qa
            )
        );
    }
    function onChange(id: any, content: any, type: any) {
        setQusa((prev) =>
            prev.map((qa) => {
                if (type == "ans")
                    return (qa.id === id ? { ...qa, ans: content } : qa);
                else
                    return (qa.id === id ? { ...qa, ques: content } : qa);
            }
            )
        );
    }
    async function handleSave(id: any) {
        const qa = qusa.find((qa) => {
            if (qa.id === id) {
                qa.isSaving = true;
                return qa;
            }
        });
        var ref;
        var newId: any;
        if (qa?.isSaved == false) {
            ref = collection(db, "que-Ans");
            const docRef = await addDoc(ref,
                {
                    paperId: pid,
                    question: qa?.ques,
                    answare: qa?.ans
                });
            newId = docRef.id;
        }
        else {
            ref = doc(db, "que-Ans", qa?.id);
            await setDoc(ref,
                {
                    paperId: pid,
                    question: qa?.ques,
                    answare: qa?.ans
                });
        }
        setQusa((prev) =>
            prev.map((qa) =>
                qa.id === id ? { ...qa, isSaving: false, id: newId, isSaved: true } : qa
            )
        );
    }
    return (
        <div className="self-start flex-1 w-full">
            <div className="bg-gray-300">
                <div className="w-full max-w-[900px] mx-auto">
                    <PaperInfo data={data} />
                </div>
            </div>
            <div className="bg-gray-600 w-full">
                <div className="flex">
                    <button
                        onClick={() => setActiveTab("paperTab")}
                        className={`p-2 ${activeTab === "paperTab"
                            ? "bg-amber-50 shadow font-medium"
                            : "bg-amber-50/70 border-e border-gray-300"
                            }`}
                    >
                        Edit Paper
                    </button>
                    <button
                        onClick={() => setActiveTab("qaTab")}
                        className={`p-2  ${activeTab === "qaTab"
                            ? "bg-amber-50 shadow font-medium"
                            : "bg-amber-50/70 border-e border-gray-300"
                            }`}
                    >
                        Edit Que Ans
                    </button>
                </div>
            </div>
            {
                activeTab == "qaTab" ? (
                    <div className="w-full max-w-[900px] mx-auto">
                        {
                            qusa.map((qa) =>
                            (
                                <div key={qa.id} className=" flex gap-4 flex-col m-5 p-4 bg-base-100 rounded">
                                    <div className="flex justify-between gap-2 items-center">
                                        <div className="flex flex-row items-center gap-2">
                                            <div className="font-bold">Q.NO</div><input className="input" type="text" />
                                        </div>
                                        <div className="flex justify-end gap-2">
                                            <button className="btn btn-sm btn-warning rounded">Delete</button>
                                            <button onClick={() => toggleHide(qa.id)} className="btn btn-sm btn-info rounded">{!qa.hide ? "Hide" : "Show"}</button>
                                        </div>
                                    </div>
                                    <div>
                                        <span className="font-bold">Question</span>
                                        <Editor id={qa.id} content={qa.ques} type="que" hide={qa.hide} onChange={onChange} />
                                    </div>
                                    {
                                        !qa.hide &&
                                        <>
                                            <div>
                                                <span className="font-bold">Ans.</span>
                                                <Editor id={qa.id} content={qa.ans} type="ans" onChange={onChange} />
                                            </div>
                                            <div className="flex justify-end">
                                                <button onClick={() => handleSave(qa.id)} className="btn btn-sm btn-success rounded" disabled={qa.isSaving}>{!qa.isSaving ? "save" : "saving.."}</button>
                                            </div>
                                        </>
                                    }
                                </div>
                            ))
                        }
                        <div className="flex justify-center">
                            <button onClick={add} className="btn btn-sm btn-info w-[60px] m-5">+ Add</button>
                        </div>
                    </div>
                ) :
                    (
                        <div>paper</div>
                    )
            }
        </div>
    );
}
