'use client';
import {
    Bold, Italic, Underline, Strikethrough,
    Heading1, Heading2, List, ListOrdered,
    Quote, Code, Undo, Redo,
    Heading3, AlignLeft, AlignCenter, AlignRight, AlignJustify
} from "lucide-react";

import "./css/heading.css";
import "./css/orderList.css";
import "./css/alignment.css";
import "./css/fontFaimaly.css";

export default function MenuBar({ editor, onEditQuestion, onEditAnswer, onDelete, onAddHint }: any) {
    if (!editor) return null;

    return (
        <>
            <style jsx>
                {`
          .button {
            border: 1px solid black;
            padding: 5px 10px;
            min-width: 24px;
            border-radius: 3px;
            cursor: pointer;
            transition: background 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
          }
          .button:hover {
            background: #f3f4f6;
          }
        `}
            </style>

            <div className="flex gap-2 mb-2 pb-2 flex-wrap">
                {/* Formatting buttons */}
                <button onClick={() => editor.chain().focus().toggleBold().run()} className={`button ${editor.isActive("bold") ? "active" : ""}`}>
                    <Bold size={16} />
                </button>

                <button onClick={() => editor.chain().focus().toggleItalic().run()} className={`button ${editor.isActive("italic") ? "active" : ""}`}>
                    <Italic size={16} />
                </button>

                <button onClick={() => editor.chain().focus().toggleUnderline().run()} className={`button ${editor.isActive("underline") ? "active" : ""}`}>
                    <Underline size={16} />
                </button>

                <button onClick={() => editor.chain().focus().toggleStrike().run()} className={`button ${editor.isActive("strike") ? "active" : ""}`}>
                    <Strikethrough size={16} />
                </button>
                {/* Font style */}
                <select className={`button`}
                    onChange={(e) =>
                        editor.chain().focus().setFontFamily(e.target.value).run()
                    }
                    value={editor?.getAttributes('textStyle')?.fontFamily || 'Arial'}
                >
                    <option value="Arial">Arial</option>
                    <option value="Times New Roman">Times New Roman</option>
                    <option value="Courier New">Courier New</option>
                    <option value="Verdana">Verdana</option>
                </select>
                {/* {font Size} */}
                <select
                    onChange={(e) =>
                        editor?.chain().focus().setMark('textStyle', { fontSize: e.target.value }).run()
                    }
                    value={editor?.getAttributes('textStyle').fontSize || '16px'}
                    className={`button`}
                >
                    <option value="12px">12</option>
                    <option value="14px">14</option>
                    <option value="16px">16</option>
                    <option value="18px">18</option>
                    <option value="20px">20</option>
                    <option value="24px">24</option>
                </select>
                {/* Headings */}
                <button onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()} className={`button ${editor.isActive("heading", { level: 1 }) ? "active" : ""}`}>
                    <Heading1 size={16} />
                </button>

                <button onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()} className={`button ${editor.isActive("heading", { level: 2 }) ? "active" : ""}`}>
                    <Heading2 size={16} />
                </button>

                <button onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()} className={`button ${editor.isActive("heading", { level: 3 }) ? "active" : ""}`}>
                    <Heading3 size={16} />
                </button>

                {/* Lists */}
                <button onClick={() => editor.chain().focus().toggleBulletList().run()} className={`button ${editor.isActive("bulletList") ? "active" : ""}`}>
                    <List size={16} />
                </button>

                <button onClick={() => editor.chain().focus().toggleOrderedList().run()} className={`button ${editor.isActive("orderedList") ? "active" : ""}`}>
                    <ListOrdered size={16} />
                </button>
                {/* {AlignMent} */}
                <button
                    onClick={() => editor.chain().focus().setTextAlign('left').run()}
                    className={`button ${editor.isActive({ textAlign: 'left' }) ? 'active' : ''}`}
                    title="Align Left"
                >
                    <AlignLeft size={16} />
                </button>

                {/* Center Align */}
                <button
                    onClick={() => editor.chain().focus().setTextAlign('center').run()}
                    className={`button ${editor.isActive({ textAlign: 'center' }) ? 'active' : ''}`}
                    title="Align Center"
                >
                    <AlignCenter size={16} />
                </button>

                {/* Right Align */}
                <button
                    onClick={() => editor.chain().focus().setTextAlign('right').run()}
                    className={`button ${editor.isActive({ textAlign: 'right' }) ? 'active' : ''}`}
                    title="Align Right"
                >
                    <AlignRight size={16} />
                </button>

                <button
                    onClick={() => editor.chain().focus().setTextAlign('justify').run()}
                    className={`button ${editor.isActive({ textAlign: 'justify' }) ? 'is-active' : ''}`}
                >
                    <AlignJustify size={16} />
                </button>
                {/* Blockquote */}
                <button onClick={() => editor.chain().focus().toggleBlockquote().run()} className={`button ${editor.isActive("blockquote") ? "active" : ""}`}>
                    <Quote size={16} />
                </button>

                {/* Code block */}
                <button onClick={() => editor.chain().focus().toggleCodeBlock().run()} className={`button ${editor.isActive("codeBlock") ? "active" : ""}`}>
                    <Code size={16} />
                </button>

                {/* Undo / Redo */}
                <button onClick={() => editor.chain().focus().undo().run()} className="button">
                    <Undo size={16} />
                </button>

                <button onClick={() => editor.chain().focus().redo().run()} className="button">
                    <Redo size={16} />
                </button>
            </div>
        </>
    );
}
