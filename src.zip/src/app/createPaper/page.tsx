'use client';
import { db } from "@/firebase/firebaseConfig";
import { addDoc, collection, doc, getDocs, serverTimestamp, setDoc } from "firebase/firestore";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";

export default function CreatePaper({ paperInfo }: any) {
    const router = useRouter();
    const [loadingSubjects, setLoadingSubjects] = useState(true);
    const [subjects, setSubjects] = useState<{ id: string; subject: string; subCode: any; description?: string; createdAt?: any }[]>([]);
    const [subject, setSubject] = useState('');
    const [year, setYear] = useState('');
    const [season, setSeason] = useState('');
    const [course, setCourse] = useState('');
    const [branch, setBranch] = useState('');
    const [semester, setSemester] = useState('');
    const [saving, setSaving] = useState(false);
    const SEASONS = ['Mid Semester', 'End Semester', 'Summer', 'Winter'];
    const COURSE = ['B.Tech', 'Polytechnic'];
    const SEMESTERS = ['1', '2', '3', '4', '5', '6', '7', '8'];
    const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
    const BRANCHES = [
        'CSE',
        'IT',
        'ECE',
        'EEE',
        'ME',
        'CE',
        'AE',
        'CHE',
    ];
    useEffect(() => {
        let mounted = true;
        async function fetchSubjects() {
            try {
                const subRef = collection(db, "subjects");
                const snapshot = await getDocs(subRef);
                const data = snapshot.docs.map((d) => {
                    const docData = d.data() as {
                        subject: string;
                        subCode: any;
                        description?: string;
                        createdAt?: any;
                    };
                    return { id: d.id, ...docData }
                });
                if (mounted) {
                    setSubjects(data)
                    if (paperInfo) {
                        setSubject(paperInfo.subject);
                        setYear(paperInfo.year);
                        setSeason(paperInfo.season);
                        setCourse(paperInfo.course);
                        setBranch(paperInfo.branch);
                        setSemester(paperInfo.semester);
                    }
                };

            } catch (error) {
                console.error("Error from create paper", error);
            }
            finally {
                if (mounted) setLoadingSubjects(false);
            }
        }
        fetchSubjects();
        return () => {
            mounted = false;
        };
    }, []);
    const resetForm = () => {
        setCourse('');
        setSubject('');
        setYear('');
        setSeason('');
        setBranch('');
        setSemester('');
    };
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setMessage(null);
        // simple validation
        if (!subject) {
            setMessage({ type: 'error', text: 'Please select a subject.' });
            return;
        }
        if (!year.trim()) {
            setMessage({ type: 'error', text: 'Please enter a year.' });
            return;
        }
        if (!/^\d{4}$/.test(year.trim())) {
            setMessage({ type: 'error', text: 'Year must be a 4-digit number (e.g., 2025).' });
            return;
        }
        setSaving(true);

        try {
            const selectedSubject = subjects.find((s) => s.subject === subject);
            if (!selectedSubject) {
                setMessage({ type: "error", text: "Invalid subject selected." });
                setSaving(false);
                return;
            }
            var docRef: any;
            if (paperInfo) {
                const Ref = doc(db, "papers", paperInfo.id);
                await setDoc(Ref, {
                    course,
                    subject: selectedSubject.subject,
                    year,
                    season,
                    branch,
                    semester,
                    createdAt: serverTimestamp(),
                });
                setMessage({ type: "success", text: "Paper Updated!" });
            }
            else {
                const papersRef = collection(db, "papers");
                docRef = await addDoc(papersRef, {
                    course,
                    subject: selectedSubject.subject,
                    year,
                    season,
                    branch,
                    semester,
                    createdAt: serverTimestamp(),
                });
                resetForm();
                setMessage({ type: "success", text: "Paper created successfully!" });
                router.push(`/editPQA?id=${docRef.id}`);
            }
        }
        catch (error) {
            console.error(error);
        }
        finally {
            setSaving(false);
        }
    }
    return (
            <div className="p-4 max-w-3xl mx-auto">
                <div className="card bg-base-100 shadow-md">
                    <div className="card-body">
                        <h2 className="card-title">{paperInfo ? "Update Paper" : "Create New Paper"}</h2>
                        <form onSubmit={handleSubmit} className="mt-4 grid grid-cols-2 md:grid-cols-2 gap-4">
                            {/* Course */}
                            <div className="form-control w-full">
                                <label className="label">
                                    <span className="label-text">Course</span>
                                </label>
                                <select
                                    className="select select-bordered w-full"
                                    value={course}
                                    onChange={(e) => setCourse(e.target.value)}
                                >
                                    <option>Select course...</option>
                                    {COURSE.map((c) => (
                                        <option key={c} value={c}>
                                            {c}
                                        </option>
                                    ))}
                                </select>
                            </div>
                            <div className="form-control w-full">
                                <label className="label">
                                    <span className="label-text">Subject</span>
                                </label>
                                {
                                    loadingSubjects ? (
                                        <select className="select select-bordered w-full" disabled>
                                            <option>Loading subjects..</option>
                                        </select>
                                    ) : subjects.length == 0 ? (
                                        <div className="text-sm text-yellow-600">No subjects found. Create subjects first.</div>
                                    ) :
                                        (
                                            <select
                                                className="select w-full select-bordered"
                                                value={subject}
                                                onChange={(e) => setSubject(e.target.value)}
                                            >
                                                <option>Select subject...</option>
                                                {
                                                    subjects.map((s) =>
                                                    (
                                                        <option key={s.id} value={s.subject}>
                                                            {s.subject + " (" + s.subCode + ")"}
                                                        </option>
                                                    ))
                                                }
                                            </select>
                                        )
                                }
                            </div>
                            {/* YEAR */}
                            <div className="form-controll w-full">
                                <label className="label">
                                    <span className="label-text">Year</span>
                                </label>
                                <input
                                    type="text"
                                    inputMode="numeric"
                                    pattern="\d*"
                                    placeholder="e.g. 2025"
                                    value={year}
                                    onChange={(e) => setYear(e.target.value)}
                                    className="input input-bordered w-full"
                                />
                            </div>
                            {/* SEASONS */}
                            <div className="form-control w-full">
                                <label className="label">
                                    <span className="label-text">Season</span>
                                </label>
                                <select
                                    className="select select-bordered w-full"
                                    value={season}
                                    onChange={(e) => setSeason(e.target.value)}
                                >
                                    <option>Select season...</option>
                                    {SEASONS.map((s) => (
                                        <option key={s} value={s}>
                                            {s}
                                        </option>
                                    ))}
                                </select>
                            </div>
                            {/* BRANCH */}
                            <div className="form-control w-full">
                                <label className="label">
                                    <span className="label-text">Branch</span>
                                </label>
                                <select
                                    className="select select-bordered w-full"
                                    value={branch}
                                    onChange={(e) => setBranch(e.target.value)}
                                >
                                    <option>Select branch..</option>
                                    {BRANCHES.map((b) => (
                                        <option key={b} value={b}>
                                            {b}
                                        </option>
                                    ))}
                                </select>
                            </div>
                            {/* SEMESTER */}
                            <div className="form-control w-full">
                                <label className="label">
                                    <span className="label-text">Semester</span>
                                </label>
                                <select
                                    className="select select-bordered w-full"
                                    value={semester}
                                    onChange={(e) => setSemester(e.target.value)}
                                >
                                    <option>Select semester...</option>
                                    {SEMESTERS.map((s) => (
                                        <option key={s} value={s}>
                                            {s}
                                        </option>
                                    ))}
                                </select>
                            </div>
                            <div className="">
                                {message && (
                                    <div
                                        className={`px-2 py-2 rounded text-sm ${message.type === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                                            }`}
                                    >
                                        {message.text}
                                    </div>
                                )}
                            </div>
                            <div className="flex flex-row justify-end items-center">
                                <div className="flex gap-2">
                                    <button
                                        type="button"
                                        onClick={resetForm}
                                        className="btn bg-yellow-300"
                                        disabled={saving}
                                    >
                                        Reset
                                    </button>
                                    <button
                                        type="submit"
                                        className={`btn btn-success`}//${saving ? 'loading' : ''}
                                        disabled={saving || loadingSubjects || subjects.length === 0}
                                    >
                                        {saving ? paperInfo ? 'Updating' : 'Saving' : paperInfo ? 'Update' : 'Save'}
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
    );
}