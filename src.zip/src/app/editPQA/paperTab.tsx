'use client';

import { useEffect, useState } from "react";
import Editor from "./Editor";
import { addDoc, collection, deleteDoc, doc, getDocs, setDoc } from "firebase/firestore";
import { db } from "@/firebase/firebaseConfig";
import { useSearchParams } from "next/navigation";

function generateId() {
  return typeof crypto?.randomUUID === "function"
    ? crypto.randomUUID()
    : Math.random().toString(36).substring(2, 10) + Date.now().toString(36);
}

export default function PaperTab() {
  const pid = useSearchParams().get("id");
  const [pages, setPages] = useState<any[]>([]);

  useEffect(() => {

    async function getPaper() {
      try {
        if (!pid) return;
        const docref = collection(db, "papers", pid, "paper");
        const snapshot = await getDocs(docref);
        const result = snapshot.docs.map(doc => ({
          id: doc.id,
          paper: doc.data().pages,
          hide: false,
          isSaved: true,
          isSaving: false,
          onChange: false
        }));
        setPages(result);
      } catch (error) {
        console.error("Error fetching pages:", error);
      }
    }
    getPaper();
  }, [pid]);

  const addPage = () => {
    setPages(prev => [
      ...prev,
      { id: generateId(), paper: "", hide: false, isSaved: false, isSaving: false, onChange: false }
    ]);
  };

  const toggleHide = (id: string) => {
    setPages(prev => prev.map(p => p.id === id ? { ...p, hide: !p.hide } : p));
  };

  const onChange = (id: any, content: any) => {
    setPages(prev => prev.map(p => p.id === id ? { ...p, paper: content, onChange: true } : p));
  };

  const handleSave = async (id: string) => {
    if (!pid) return;
    setPages(prev => prev.map(p => p.id === id ? { ...p, isSaving: true } : p));

    const page = pages.find(p => p.id === id);
    let newId:any;

    if (!page.isSaved) {
      const docRef = await addDoc(collection(db, "papers", pid, "paper"), {
        pageNo: pid,
        pages: page.paper
      });
      newId = docRef.id;
    } else {
      await setDoc(doc(db, "papers", pid, "paper", page.id), {
        pageNo: pid,
        pages: page.paper
      });
    }

    setPages(prev => prev.map(p => p.id === id ? {
      ...p, isSaving: false, isSaved: true, onChange: false, id: newId || p.id
    } : p));
  };

  const handleDelete = async (id: string) => {
    if (!pid) return;
    if (!confirm("Are you sure you want to delete this page?")) return;

    try {
      await deleteDoc(doc(db, "papers", pid, "paper", id));
      setPages(prev => prev.filter(p => p.id !== id));
      alert("Deleted");
    } catch (error) {
      console.error("Delete error:", error);
    }
  };

  return (
    <div className="w-full max-w-[900px] mx-auto">
      {pages.map(p => (
        <div key={p.id} className="flex flex-col gap-4 mb-2 p-4 bg-base-100 rounded">
          <div className="flex justify-between items-center">
            <span className="font-bold">Page</span>
            <div className="flex gap-2">
              <button onClick={() => handleDelete(p.id)} className="btn btn-sm btn-error">Delete</button>
              <button onClick={() => toggleHide(p.id)} className="btn btn-sm btn-info">
                {p.hide ? "Show More" : "Show Less"}
              </button>
            </div>
          </div>
          <Editor
            id={p.id}
            content={p.paper}
            type="paper"
            hide={p.hide}
            height={!p.hide ? "min-height:110px" : "height:38px"}
            onChange={onChange}
          />
          {!p.hide && (
            <div className="flex justify-end">
              <button
                onClick={() => handleSave(p.id)}
                className={`btn btn-sm rounded ${p.onChange ? "bg-yellow-500" : "btn-success"}`}
                disabled={p.isSaving}
              >
                {!p.isSaving ? "Save" : "Saving..."}
              </button>
            </div>
          )}
        </div>
      ))}
      <div className="flex justify-center">
        <button onClick={addPage} className="btn btn-sm btn-info m-5 w-[60px]">+ Add</button>
      </div>
    </div>
  );
}
