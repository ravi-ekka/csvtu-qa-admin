'use client';

import { useEffect, useState } from "react";
import Editor from "./Editor";
import { addDoc, collection, deleteDoc, doc, getDocs, query, setDoc, where } from "firebase/firestore";
import { db } from "@/firebase/firebaseConfig";
import { useSearchParams } from "next/navigation";

function generateId() {
  return typeof crypto?.randomUUID === "function"
    ? crypto.randomUUID()
    : Math.random().toString(36).substring(2, 10) + Date.now().toString(36);
}

export default function QaTab() {
  const pid = useSearchParams().get("id");
  const [qas, setQas] = useState<any[]>([]);

  useEffect(() => {
    if (!pid) return;

    async function fetchQas() {
      try {
        const qry = query(collection(db, "que-Ans"), where("paperId", "==", pid));
        const snapshot = await getDocs(qry);
        const result = snapshot.docs.map(doc => ({
          id: doc.id,
          ques: doc.data().question,
          ans: doc.data().answare,
          hide: false,
          isSaved: true,
          isSaving: false,
          onChange: false
        }));
        setQas(result);
      } catch (error) {
        console.error("Error fetching QA:", error);
      }
    }

    fetchQas();
  }, [pid]);

  const addQa = () => {
    setQas(prev => [
      ...prev,
      { id: generateId(), ques: "", ans: "", hide: false, isSaved: false, isSaving: false, onChange: false }
    ]);
  };

  const toggleHide = (id: string) => {
    setQas(prev => prev.map(q => q.id === id ? { ...q, hide: !q.hide } : q));
  };

  const onChange = (id: string, content: string, type: "ques" | "ans") => {
    setQas(prev => prev.map(q => q.id === id ? { ...q, [type]: content, onChange: true } : q));
  };

  const handleSave = async (id: string) => {
    setQas(prev => prev.map(q => q.id === id ? { ...q, isSaving: true } : q));
    const qa = qas.find(q => q.id === id);
    let newId: string;

    if (!qa?.isSaved) {
      const docRef = await addDoc(collection(db, "que-Ans"), {
        paperId: pid,
        question: qa?.ques,
        answare: qa?.ans
      });
      newId = docRef.id;
    } else {
      await setDoc(doc(db, "que-Ans", qa?.id), {
        paperId: pid,
        question: qa?.ques,
        answare: qa?.ans
      });
    }

    setQas(prev => prev.map(q => q.id === id ? { ...q, isSaved: true, isSaving: false, onChange: false, id: newId || q.id } : q));
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this QA?")) return;
    try {
      await deleteDoc(doc(db, "que-Ans", id));
      setQas(prev => prev.filter(q => q.id !== id));
      alert("Deleted");
    } catch (error) {
      console.error("Delete error:", error);
    }
  };

  return (
    <div className="w-full max-w-[900px] mx-auto">
      {qas.map(q => (
        <div key={q.id} className="flex flex-col gap-4 mb-2 p-4 bg-base-100 rounded">
          <div className="flex justify-between items-center">
            <span className="font-bold">Q.No</span>
            <div className="flex gap-2">
              <button onClick={() => handleDelete(q.id)} className="btn btn-sm btn-error">Delete</button>
              <button onClick={() => toggleHide(q.id)} className="btn btn-sm btn-info">
                {q.hide ? "Show More" : "Show Less"}
              </button>
            </div>
          </div>
          <Editor
            id={q.id}
            content={q.ques}
            type="ques"
            hide={q.hide}
            height={!q.hide ? "min-height:110px" : "height:38px"}
            onChange={onChange}
          />
          {!q.hide && (
            <>
              <span className="font-bold">Ans.</span>
              <Editor
                id={q.id}
                content={q.ans}
                type="ans"
                height="min-height:110px"
                hide={q.hide}
                onChange={onChange}
              />
              <div className="flex justify-end">
                <button
                  onClick={() => handleSave(q.id)}
                  className={`btn btn-sm rounded ${q.onChange ? "bg-yellow-500" : "btn-success"}`}
                  disabled={q.isSaving}
                >
                  {!q.isSaving ? "Save" : "Saving..."}
                </button>
              </div>
            </>
          )}
        </div>
      ))}
      <div className="flex justify-center">
        <button onClick={addQa} className="btn btn-sm btn-info m-5 w-[60px]">+ Add</button>
      </div>
    </div>
  );
}
